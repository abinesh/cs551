#ifndef _COMMON_H_
#define _COMMON_H_

typedef struct config_tag{
    int stage_num;
    int num_nodes;
    int nonce;
}config;

#define MSG_SIZE 1024

#endif /*_COMMON_H_*/
