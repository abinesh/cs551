#include "common.h"

void manager_fun(config c, int manager_sock_fd, FILE *log_file);
